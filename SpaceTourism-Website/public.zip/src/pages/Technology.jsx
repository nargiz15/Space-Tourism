

const Technology = () => {
  return (
    <div>Technology</div>
  )
}

export default Technology